from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import StafForm,StafModelForm
from.models import Staffmodel
from django.contrib import messages
from django.views.generic import View
from django.utils.decorators import method_decorator
# Create your views here.

# dec
def signin_required(fn):
    def wrapper(request,*args,**kwargs):
        if request.user.is_authenticated:
            return fn(request,*args,**kwargs)
        else:
            return redirect("log")
    return wrapper


def mngresponse(request):
    return HttpResponse("manager Application")

class Staf(View):
    def get(self,request,*args,**kwargs):
        f=StafForm()
        return render(request,"addstaff.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=StafForm(data=request.POST)
        if form_data.is_valid():
           fn=form_data.cleaned_data.get('first_name')
           ln=form_data.cleaned_data.get('last_name')
           email=form_data.cleaned_data.get('email')
           ph=form_data.cleaned_data.get('phone')
           expe=form_data.cleaned_data.get('exp')
           Staffmodel.objects.create(first_name=fn,last_name=ln,email=email,phone=ph ,exp=expe)
           messages.success(request,"successfully submited")
           return redirect('h')
        else:
           messages.error(request,"submission failed")
           return render(request,"addstaff.html",{"form":form_data})



class Editstaff(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("arg")
        staff=Staffmodel.objects.get(id=id)
        f=StafForm(initial={"first_name":staff.first_name,"last_name":staff.last_name,"email":staff.email,"phone":staff.phone,"exp":staff.exp})
        return render(request,"editstaf.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=StafForm(data=request.POST)
        if form_data.is_valid():
            fn=form_data.cleaned_data.get('first_name')
            ln=form_data.cleaned_data.get('last_name')
            e=form_data.cleaned_data.get('email')
            ph=form_data.cleaned_data.get('phone')
            ex=form_data.cleaned_data.get('exp')
            id=kwargs.get("arg")
            staff=Staffmodel.objects.get(id=id)
            staff.first_name=fn
            staff.last_name=ln
            staff.email=e
            staff.phone=ph
            staff.exp=ex
            staff.save()
            messages.success(request,"updated")
            return redirect("vstaff")
        else:
            return render(request,"editstaf.html",{"form":form_data})  
class ViewStaf(View):
    def get(self,request,*args,**kwargs):
        variable=Staffmodel.objects.all()
        return render(request,'viewstafs.html',{"key":variable})

# using modelform
@method_decorator(signin_required,name='dispatch')
class StafMView(View):
    def get(self,request,*args,**kwargs):
            f=StafModelForm()
            return render(request,"addstaff.html",{"form":f})
       
    def post(self,request,*args,**kwargs):
         form_data=StafModelForm(data=request.POST,files=request.FILES)
         if form_data.is_valid():
           form_data.save()
           messages.success(request,"successfully submitted")
           return redirect('h')
         else:
           messages.error(request,"submission failed")
           return render(request,"addstaff.html",{"form":form_data})
       



        



class MeditStafView(View):
    def get(self,request,*args,**kwargs):
        id=kwargs.get("arg")
        staff=Staffmodel.objects.get(id=id)
        print(staff.first_name,"jjjjj")
        f=StafModelForm(instance=staff)
        return render(request,"editstaf.html",{"form":f})
    def post(self,request,*args,**kwargs):
       id=kwargs.get("arg")
       staff=Staffmodel.objects.get(id=id)
       form_data=StafModelForm(data=request.POST,instance=staff,files=request.FILES)
       if form_data.is_valid():
            form_data.save()
            messages.success(request,"staf details updated successfully!!")
            return redirect("vstaff")
       else:
            return render(request,"editstaf.html",{"form":form_data})

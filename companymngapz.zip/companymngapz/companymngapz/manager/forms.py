from django import forms
from .models import *

class StafForm(forms.Form):
    first_name=forms.CharField( max_length=15, required=False,label="FIRSTNAME",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter the first name"}))
    last_name=forms.CharField( max_length=15, required=False,label="LASTNAME",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter the last name"}))
    email=forms.CharField( max_length=15, required=False,label="EMAIL",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter the email"}))
    phone=forms.IntegerField(label="PHONE",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter the phone number"}))
    exp=forms.IntegerField(label="EXPERIENCE",widget=forms.TextInput(attrs={"class":"form-control","placeholder":"enter the experience"}))
    def clean(self):
        cleaned_data=super().clean()
        e=cleaned_data.get('exp')
        if e<0:
            self.add_error("exp","exp canot less than ")

class StafModelForm(forms.ModelForm):
    class Meta:
           model=Staffmodel
           fields="__all__"
           widgets={
                "first_name":forms.TextInput(attrs={"class":"form-control"}),
                "last_name":forms.TextInput(attrs={"class":"form-control"}),
                "email":forms.EmailInput(attrs={"class":"form-control"}),
                "phone":forms.NumberInput(attrs={"class":"form-control"}),
                "exp":forms.NumberInput(attrs={"class":"form-control"}),
                
        }
    # def clean(self):
    #         cleaned_data=super().clean()
    #         e=cleaned_data.get('exp')
    #         if e<=0:
    #             self.add_error("exp","exp cannot less than 0")
             

        
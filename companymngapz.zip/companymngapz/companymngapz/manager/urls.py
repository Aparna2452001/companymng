from django.urls import path
from .views import *

urlpatterns=[
    path('addstaf/',StafMView.as_view(),name="addstaff"),
    path('editstaff/<int:arg>',MeditStafView.as_view(),name="editstaff"),
    path('viewstaff/',ViewStaf.as_view(),name="vstaff"),
]


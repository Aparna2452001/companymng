from django.shortcuts import render,redirect
from django.views.generic import View
from .forms import AddForms

class AddView(View):
    def get(self,request,*args,**kwargs):
        form=AddForms
        return render(request,"add.html",{'forms':form})
    def post(self,request,*args,**kwargs):
        
        form_data=AddForms(request.POST)
        if form_data.is_valid():
            print(form_data.cleaned_data.get("num1"))
            print(form_data.cleaned_data.get("num2"))
            return redirect('h')
        else:
            return render(request,"add.html",{'forms':form_data})



class SubsView(View):
    def get(self,request,*args,**kwargs):
        form=AddForms
        return render(request,"subs.html",{'forms':form})
    def post(self,request,*args,**kwargs):
        form_data=AddForms(request.POST)
        if form_data.is_valid():
            print(form_data.cleaned_data.get("num1"))
            print(form_data.cleaned_data.get("num2"))
            return redirect('h')
            
        else:
            return render(request,"subs.html",{'forms':form_data})









# Create your views here.

      





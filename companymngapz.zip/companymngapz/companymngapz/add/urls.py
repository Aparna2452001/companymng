from django.urls import path
from .views import AddView,SubsView


urlpatterns = [
    path('add/',AddView.as_view(),name="add"),
    # path('word/',countView.as_view(),name="word"),
    path('subst/',SubsView.as_view(),name="subs")
]



from django import forms


class AddForms(forms.Form):
    num1=forms.IntegerField()
    num1=forms.IntegerField()

class RegForms(forms.Form):
    name=forms.CharField( max_length=100, required=False,label="name",widget=forms.TextInput(attrs={"class":"form-contol","placeholder":" name"}))
    usernae=forms.CharField( max_length=100, required=False,label="user name",widget=forms.TextInput(attrs={"class":"form-contol","placeholder":"user name"}))
    email=forms.EmailField( max_length=100, required=False,label="email",widget=forms.TextInput(attrs={"class":"form-contol","placeholder":"email"}))
   
    
    exper=forms.IntegerField(label="exper",widget=forms.TextInput(attrs={"class":"form-contol","placeholder":"experience"}))
    password=forms.CharField( max_length=100, required=False,label="password",widget=forms.TextInput(attrs={"class":"form-contol","placeholder":"password"}))
    confirmpassword=forms.CharField( max_length=100, required=False,label="confirmpassword",widget=forms.TextInput(attrs={"class":"form-contol","placeholder":"confirm psw"}))
    def clean(self):
        cleand_data=super().clean()
        f=cleand_data.get("name")
        l=cleand_data.get("usernae")
        e=cleand_data.get("exper")
       
        if f==l:
            msg="same"
            self.add_error("name",msg)
            self.add_error("usernae",msg)
        if e<0:
            msg="exp cannot less than0"
            self.add_error(msg,"exper")

        


class AddLog(forms.Form):
    uname=forms.CharField(label="username",widget=forms.TextInput(attrs={"class":"form-contol"}))
    pswd=forms.CharField(label="passwor",widget=forms.TextInput(attrs={"class":"form-contol","placeholder":" name"}))
    




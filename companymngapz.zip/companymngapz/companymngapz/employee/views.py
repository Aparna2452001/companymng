from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.views.generic import View
from .forms import RegForms,AddLog
from django.contrib import messages
from  .models import Employee


# Create your views here.
def index(request):
    return HttpResponse("Hello World")


def home(request):
    name=request.user
    return render(request,"home.html",{'data':name})




class ViewStaf(View):
    def get(self,request,*args,**kwargs):
        variable=Employee.objects.all()
        return render(request,'viewstafs.html',{"key":variable})
    
     


# def reg(request):
#     if request.method=="GET":
#         return render(request,"reg.html")
#     if request.method=="POST":
#         name=request.POST.get('fname')
#         usrname=request.POST.get('uname')
#         mail=request.POST.get('email')
#         password=request.POST.get('password')
#         cnfrm=request.POST.get('confirmpassword')
#         if password==cnfrm: 
#             return HttpResponse("name:"+name+",username:"+usrname+",email:"+mail)
#         else:
#             return HttpResponse("pasword missmatches")
# class AddView(View):
#     def get(self,request,*args,**kwargs):
#         form=AddForm()





        # if password==confirmpassword: 
        #     return HttpResponse("name:"+name+",username:"+usrname+",email:"+email)
        # else:
        #     return HttpResponse("pasword missmatches")
         


class count(View):
    def get(self,request,*args,**kwargs):
        return render(request,"word.html")
    def post(self,request,*args,**kwargs):
        string=request.POST.get('GHJ')
        word=string.split(" ")
        sent={}
        for i in word:
            if i in sent:
                sent[i]+=1
            else:
                sent[i]=1
        return render(request,"word.html",{'ans':sent})       


    







# def reg(request):
    
#         return render(request,"reg.html")
#     if request.method=="POST":
#         name=request.POST.get('fname')
#         usrname=request.POST.get('uname')
#         mail=request.POST.get('email')
#         password=request.POST.get('password')
#         cnfrm=request.POST.get('confirmpassword')




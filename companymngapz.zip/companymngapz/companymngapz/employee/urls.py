from django.urls import path
from .views import *


urlpatterns = [
    path('index/',index),
    path('wordcount/',count.as_view()),
    path('viewstaff/',ViewStaf.as_view(),name="ViewStaf"),
    path('home/',home,name='h'),
    
    
    
]


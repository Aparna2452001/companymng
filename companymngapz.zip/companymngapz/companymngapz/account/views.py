from django.shortcuts import render,redirect
from django.views.generic import View
from .forms import UserRegForm,LogForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout



# Create your views here.
class MainHome(View):
    def get(self,request,*args,**kwargs):
        return render(request,"main_home.html")

class Log(View):
     def get(self,request,*args,**kwargs):
         f=LogForm()
         return render(request,"log.html",{"key":f})
     def post(self,request,*args,**kwargs):
        form_data=LogForm(data=request.POST)
        if form_data.is_valid():
            uname=form_data.cleaned_data.get("username")
            pswd=form_data.cleaned_data.get("password")
            user=authenticate(request,username=uname,password=pswd)
            if user:
                login(request,user)
                messages.success(request,"Login successfull!!")
                return redirect("h")
            else:
                messages.error(request,"Login failed")
                return redirect("log")
        else:
            return render(request,"log.html",{"key":form_data})




class LogOut(View):
    def get(self,request):
        logout(request)
        return redirect("mh")


    




class reg_view(View):

    def get(self,request,*args,**kwargs):
        f=UserRegForm()
        return render(request,"reg.html",{"key":f})
    def post(self,request,*args,**kwargs):
        form_data=UserRegForm(data=request.POST)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"user registration completed")
            return redirect("mh")
        else:
            messages.error(request,"faild")
            return render(request,"reg.html",{"key":form_data})


   
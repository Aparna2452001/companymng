from django.urls import path
from.views import*
urlpatterns = [
    path('log/', Log.as_view(),name="log"),
    path('reg/',reg_view.as_view(),name="reg"),
    path('logout/',LogOut.as_view(),name="logout"),
    
]
